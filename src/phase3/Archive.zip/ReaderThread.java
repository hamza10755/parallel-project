package parallelproject.phase3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PipedWriter;

/**
 * ReaderThread reads the dataset file line by line (skipping the header)
 * and sends each line through a PipedWriter to a connected ProcessorThread.
 */
public class ReaderThread implements Runnable {

    private String filePath;
    private PipedWriter writer;

    public ReaderThread(String filePath, PipedWriter writer) {
        this.filePath = filePath;
        this.writer = writer;
    }

    @Override
    public void run() {
        try (BufferedReader fileReader = new BufferedReader(new FileReader(filePath));
             PipedWriter autoClose = writer) {

            fileReader.readLine(); // skip header row

            String line;
            while ((line = fileReader.readLine()) != null) {
                // write each data line into the pipe
                writer.write(line + "\n");
            }

        } catch (IOException ex) {
            System.getLogger(ReaderThread.class.getName())
                  .log(System.Logger.Level.ERROR, (String) null, ex);
        }
    }
}
