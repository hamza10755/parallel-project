package parallelproject.phase3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PipedReader;

/**
 * ProcessorThread reads lines from a PipedReader (sent by ReaderThread),
 * applies the complex filter, and prints the total matching count.
 *
 * Filter: Elevation > 2800, Slope < 10, Horiz_Dist_Hydro < 50
 */
public class ProcessorThread implements Runnable {

    private PipedReader reader;
    private int count;

    public ProcessorThread(PipedReader reader) {
        this.reader = reader;
        this.count = 0;
    }

    @Override
    public void run() {
        try (BufferedReader buffered = new BufferedReader(reader)) {
            String line;
            while ((line = buffered.readLine()) != null) {
                String[] parts = line.split(",");
                double elevation = Double.parseDouble(parts[0].trim());
                double slope = Double.parseDouble(parts[2].trim());
                double hydro = Double.parseDouble(parts[3].trim());

                if (elevation > 2800 && slope < 10 && hydro < 50) {
                    count++;
                }
            }
            System.out.println("Pipe result: " + count + " matching records");
        } catch (IOException ex) {
            System.getLogger(ProcessorThread.class.getName())
                  .log(System.Logger.Level.ERROR, (String) null, ex);
        }
    }

    public int getCount() {
        return count;
    }
}
