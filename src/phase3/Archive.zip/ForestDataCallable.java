package parallelproject.phase3;

import java.util.List;
import java.util.concurrent.Callable;

/**
 * ForestDataCallable implements Callable<Integer>.
 * It processes a sub-list of CSV records and returns the count of lines
 * that pass the filter: Elevation > 2800, Slope < 10, Horiz_Dist_Hydro < 50.
 */
public class ForestDataCallable implements Callable<Integer> {

    private List<String> dataSublist;

    public ForestDataCallable(List<String> dataSublist) {
        this.dataSublist = dataSublist;
    }

    @Override
    public Integer call() {
        int count = 0;
        for (String record : dataSublist) {
            String[] parts = record.split(",");
            double elevation = Double.parseDouble(parts[0].trim());
            double slope = Double.parseDouble(parts[2].trim());
            double hydro = Double.parseDouble(parts[3].trim());

            if (elevation > 2800 && slope < 10 && hydro < 50) {
                count++;
            }
        }
        return count;
    }
}
