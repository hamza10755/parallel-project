package parallelproject.phase3;

import java.io.IOException;
import java.io.PipedReader;
import java.io.PipedWriter;

/**
 * PipeMain connects a ReaderThread and ProcessorThread via a pipe,
 * runs them concurrently, and measures the total execution time.
 */
public class PipeMain {

    public static void main(String[] args) {
        PipedWriter writer = new PipedWriter();
        PipedReader reader = new PipedReader();

        try {
            reader.connect(writer);
        } catch (IOException ex) {
            System.getLogger(PipeMain.class.getName())
                  .log(System.Logger.Level.ERROR, (String) null, ex);
            return;
        }

        // Use the same file path as the rest of the project
        String filePath = "forest_data_output.txt";

        ReaderThread readerTask = new ReaderThread(filePath, writer);
        ProcessorThread processorTask = new ProcessorThread(reader);

        Thread readerThread = new Thread(readerTask);
        Thread processorThread = new Thread(processorTask);

        long startTime = System.currentTimeMillis();

        readerThread.start();
        processorThread.start();

        try {
            readerThread.join();
            processorThread.join();
        } catch (InterruptedException ex) {
            System.getLogger(PipeMain.class.getName())
                  .log(System.Logger.Level.ERROR, (String) null, ex);
        }

        long elapsed = System.currentTimeMillis() - startTime;
        System.out.println("Pipe execution time: " + elapsed + " ms");
    }
}
