package parallelproject.phase3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * CallableMain reads the dataset, then tests the complex filter using
 * a thread pool with 2, 4, 8, 16, 32, 64, and 128 threads.
 * Each thread count evenly divides the data and sums the partial results
 * returned by ForestDataCallable via Future<Integer>.
 */
public class CallableMain {

    public static void main(String[] args) {
        // --- Load dataset ---
        List<String> allLines = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("forest_data_output.txt"))) {
            reader.readLine(); // skip header
            String line;
            while ((line = reader.readLine()) != null) {
                allLines.add(line);
            }
        } catch (IOException ex) {
            System.getLogger(CallableMain.class.getName())
                  .log(System.Logger.Level.ERROR, (String) null, ex);
            return;
        }
        System.out.println("Loaded " + allLines.size() + " records.\n");

        // --- Test with different thread counts ---
        int[] threadCounts = {2, 4, 8, 16, 32, 64, 128};

        for (int numThreads : threadCounts) {
            long startTime = System.currentTimeMillis();

            int result = runWithCallables(allLines, numThreads);

            long elapsed = System.currentTimeMillis() - startTime;
            System.out.println("Threads=" + numThreads + " | Count=" + result
                    + " | Time=" + elapsed + " ms");
        }
    }

    /**
     * Splits the data into numThreads chunks, submits a ForestDataCallable
     * for each chunk to an ExecutorService, collects Future results,
     * sums them, and shuts down the executor.
     */
    private static int runWithCallables(List<String> data, int numThreads) {
        int size = data.size();
        int chunk = (int) Math.ceil((double) size / numThreads);

        // Create a thread pool with the requested number of threads
        ExecutorService executor = Executors.newFixedThreadPool(numThreads);

        List<Future<Integer>> futures = new ArrayList<>();

        // Divide the dataset evenly and submit a Callable for each slice
        for (int i = 0; i < numThreads; i++) {
            int start = i * chunk;
            int end = Math.min(start + chunk, size);
            List<String> sublist = data.subList(start, end);

            ForestDataCallable task = new ForestDataCallable(sublist);
            Future<Integer> future = executor.submit(task);
            futures.add(future);
        }

        // Collect partial results from each Future
        int total = 0;
        for (Future<Integer> f : futures) {
            try {
                total += f.get();
            } catch (InterruptedException | ExecutionException ex) {
                System.getLogger(CallableMain.class.getName())
                      .log(System.Logger.Level.ERROR, (String) null, ex);
            }
        }

        // Gracefully shut down the executor
        executor.shutdown();

        return total;
    }
}
